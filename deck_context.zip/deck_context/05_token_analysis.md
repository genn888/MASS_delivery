# Token Analysis — Where the Budget Goes

> Source for the cost slides. All numbers recomputed **uniformly** across the three sessions
> from on-disk transcripts (`*/artifacts/agent_transcripts/*.json`, field `usage`) on
> 2026-06-22, so the three runs are directly comparable. (Note: per-session
> `token_usage_report.md` files exist too, but earlier ones counted a slightly different
> transcript set; the tables here are the canonical, like-for-like numbers for the deck.)

## 1. Session totals

| Configuration | Model calls | Input tokens | Output tokens | **Total tokens** |
|---|---:|---:|---:|---:|
| Qwen3.6-27B (homogeneous) | 799 | 13,638,047 | 1,304,290 | **14,942,337** |
| MiniMax-M3 (homogeneous) | 1,160 | 22,758,215 | 876,114 | **23,634,329** |
| **Mixed (M3 planning + Qwen coding)** | 917 | 21,211,550 | 1,549,788 | **22,761,338** |

Observations:
- **Qwen-only is the cheapest** (~14.9M) but also the lowest quality.
- **Mixed (~22.8M) costs slightly LESS than M3-only (~23.6M)** while scoring higher — the
  mix is strictly better than M3-everywhere on this benchmark (more quality, fewer tokens).
- M3 has the most calls (1,160) and an extreme input/output ratio (~26:1) — its agentic loop
  accumulates lots of context and emits little per turn.

## 2. Tokens per agent (total tokens, with call count)

| Agent | Qwen-only | M3-only | Mixed |
|---|---:|---:|---:|
| coder | 11,155,649 (515) | 18,145,230 (807) | 18,060,676 (621) |
| reviewer | 1,364,236 (120) | 3,373,552 (208) | 2,253,788 (151) |
| test_writer | 1,009,456 (47) | 856,178 (41) | 1,078,351 (42) |
| browser_test_writer | 789,265 (40) | 682,492 (33) | 816,210 (34) |
| architect | 384,028 (37) | 357,564 (31) | 339,492 (31) |
| planning_reviewer | 164,891 (20) | 169,370 (20) | 162,693 (19) |
| requirement_analyzer | 74,812 (20) | 49,943 (20) | 50,128 (19) |

**The single biggest insight:** the **Coder dominates the budget** in every configuration:
- Qwen-only: coder = **74.7%** of all tokens
- M3-only: coder = **76.8%**
- Mixed: coder = **79.3%**

Planning agents (requirement_analyzer + architect + planning_reviewer) together are only
**~2.5–4%** of the budget — i.e. **upgrading the planning models to M3 is almost free** in
token terms, yet it lifts quality. This is the quantitative backbone of the mixture argument:
*spend the strong model on the cheap-but-high-leverage planning roles; keep the efficient
model on the expensive coding loop.*

> Suggested chart: 100%-stacked horizontal bar per configuration, segments = agents, coder
> segment emphasized. Or a single "coder ≈ 75–80% of all tokens" callout.

## 3. Cost vs quality (the decision slide)

| Configuration | Total tokens (M) | Official score | Official score per 1M tokens |
|---|---:|---:|---:|
| Qwen-only | 14.94 | 0.504 | 0.0337 |
| M3-only | 23.63 | 0.535 | 0.0226 |
| **Mixed** | 22.76 | 0.549 | 0.0241 |

Reading:
- **Mixed dominates M3-only on both axes** — higher score *and* fewer tokens.
- **Qwen-only is the most token-efficient per quality point** (cheapest path to a "good
  enough" result), but tops out at the lowest absolute quality.
- The practical takeaway: if quality is the goal, **Mixed is the efficient frontier point**
  — it gets the best score for less than the all-strong-model cost.

> Suggested chart: scatter / quadrant, x = total tokens (cost), y = official score; three
> points labelled. Mixed sits up-and-left of M3 (better and cheaper); Qwen sits low-left.

## 4. Per-project token cost (backup material)

Per-project token totals are available in each session's `token_usage_report.md`
(e.g. for Qwen-only: project_13 = 3.24M tokens / 101 calls is the most expensive,
project_15 = 65k the cheapest; mean ≈ 747k tokens / ~40 calls). Use these for a
"token cost varies 50× across projects; retries on hard projects drive the tail" backup slide.

Per-project tables live at:
- `sessions/qwen3.6_27b_final_MAS/token_usage_report.md`
- `sessions/multi_agent_m3_final/token_usage_report.md`
- `sessions/mixed_m3_qwen3.6_final/token_usage_report.md` (regenerated for this deck)
