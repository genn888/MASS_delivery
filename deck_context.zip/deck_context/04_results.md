# Experimental Results

> Source for the results slides. Numbers extracted from each session's
> `results.json` → `aggregate` block (verified on 2026-06-22). 20 projects, 284 judge
> functions per run.

## 1. Headline — the mixture wins (the money slide)

| Configuration | Official score (fixed pass@1) | Avg project score | Local pass@1 | Judge functions passed |
|---|---:|---:|---:|---:|
| Qwen3.6-27B (homogeneous) | 0.504 | 0.589 | 0.70 | 143 / 284 |
| MiniMax-M3 (homogeneous) | 0.535 | 0.616 | 0.75 | 152 / 284 |
| **Mixed (M3 planning + Qwen coding)** | **0.549** | **0.645** | **0.75** | **156 / 284** |

**Reading of the result:**
- The **Mixed configuration is best on every quality metric.**
- Mixed vs Qwen-only: **+4.5 points** of official score (0.549 vs 0.504), +13 judge functions.
- Mixed vs M3-only: **+1.4 points** of official score and a higher average project score
  (0.645 vs 0.616) — i.e. the mix beats even the strong model used everywhere.
- Both M3-containing configurations reach 0.75 local pass@1 vs 0.70 for Qwen-only, suggesting
  **planning quality (where M3 sits in the mix) lifts completion**.

> Suggested chart: grouped bar, three bars (Qwen / M3 / Mixed), series = official score and
> average project score. Highlight the Mixed bars.

## 2. Interpretation — *why* the mix wins

- The **planning brain matters disproportionately**: putting the stronger reasoner (M3) on
  requirements + architecture + plan review produces better, more contract-complete plans, so
  the Coder starts from a stronger spec.
- The **production line is volume-bound**: coding/review/testing are dominated by call count
  and token volume; the efficient code model (Qwen) handles them well and cheaply.
- The mix captures **the best of both**: M3's reasoning where it counts, Qwen's efficiency
  where the volume is — and the combination exceeds M3-everywhere on average project score.

## 3. Honesty / caveats (good for a defense)

- Both runs left 5–6 of 20 projects pending/incomplete (`completed_projects`: Mixed 15,
  M3 15, Qwen 14) — the comparison is on the same benchmark under the same caps.
- Margins between Mixed and M3-only are modest on official score (+1.4 pts) but consistent
  across average project score and pass@1; the stronger separation is against Qwen-only.
- The decisive practical argument is **cost-adjusted** (see `05_token_analysis.md`): the mix
  matches/î beats M3 quality at materially lower planning-side intensity.

## 4. Raw aggregate (for backup slide)

```
mixed_m3_qwen3.6_final : completed=15/20 local_pass@1=0.75 official=0.549 avg=0.645 fixed_passed=156/284
multi_agent_m3_final   : completed=15/20 local_pass@1=0.75 official=0.535 avg=0.616 fixed_passed=152/284
qwen3.6_27b_final_MAS  : completed=14/20 local_pass@1=0.70 official=0.504 avg=0.589 fixed_passed=143/284
```
